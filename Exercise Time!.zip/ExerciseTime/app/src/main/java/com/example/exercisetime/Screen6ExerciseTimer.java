package com.example.exercisetime;

import androidx.appcompat.app.AppCompatActivity;

public class Screen6ExerciseTimer extends AppCompatActivity {
}
